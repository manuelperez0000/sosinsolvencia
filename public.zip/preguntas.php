<?php
    $text .= "R1: ".$_POST["p1"];
    $text .= "R2: ".$_POST["p2"];
    $text .= "R3: ".$_POST["p3"];
    $text .= "R4: ".$_POST["p4"];
    $text .= "R5: ".$_POST["p5"];
    $text .= "R6: ".$_POST["p6"];
    $text .= "R7: ".$_POST["p7"];
    $text .= "R8: ".$_POST["p8"];
    $text .= "R9: ".$_POST["p9"];
    $text .= "R10: ".$_POST["p10"];
    header("location:https://api.whatsapp.com/send?phone=584123506032&text=".$text);
?>